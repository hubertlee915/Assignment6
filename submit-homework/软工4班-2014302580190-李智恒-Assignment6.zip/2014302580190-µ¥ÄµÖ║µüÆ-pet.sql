CREATE TABLE `2014302580190_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `property` varchar(45) DEFAULT NULL,
  `peculiarity` varchar(45) DEFAULT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`,`name`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;